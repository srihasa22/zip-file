#ifndef GROCERY_STORE_H
#define GROCERY_STORE_H

// Structure to hold grocery item information
struct GroceryItem {
    char name[50];
    float price;
};

void displayMenu(struct GroceryItem items[], int size);
void getCustomerDetails(char *name, char *email, char *address);
int login(const char *username, const char *password, const char* const expectedUsername, const char* const expectedPassword);
void saveOrder(const char *name, const char *email, const char *address, const struct GroceryItem *item, int quantity);
void searchOrder(const char *name);

#endif // GROCERY_STORE_H
