#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "grocery_store.h"

void displayMenu(struct GroceryItem items[], int size) {
    printf("Menu:\n");
    for (int i = 0; i < size; ++i) {
        printf("%d. %s - $%.2f\n", i + 1, items[i].name, items[i].price);
    }
}

void getCustomerDetails(char *name, char *email, char *address) {
    printf("\nEnter your name: ");
    scanf("%49s", name); // Limit input to prevent buffer overflow
    printf("Enter your email: ");
    scanf("%99s", email); // Limit input to prevent buffer overflow
    printf("Enter your address: ");
    scanf("%99s", address); // Limit input to prevent buffer overflow
}

int login(const char *username, const char *password, const char* const expectedUsername, const char* const expectedPassword) {
    if (strcmp(username, expectedUsername) == 0 && strcmp(password, expectedPassword) == 0) {
        return 1; // Login successful
    } else {
        return 0; // Login failed
    }
}

void saveOrder(const char *name, const char *email, const char *address, const struct GroceryItem *item, int quantity) {
    FILE *file = fopen("orders.txt", "a");
    if (file == NULL) {
        perror("Unable to open file");
        exit(1);
    }
    fprintf(file, "Customer Name: %s\n", name);
    fprintf(file, "Customer Email: %s\n", email);
    fprintf(file, "Customer Address: %s\n", address);
    fprintf(file, "Item: %s\n", item->name);
    fprintf(file, "Quantity: %d\n", quantity);
    fprintf(file, "Total: $%.2f\n\n", item->price * quantity);
    fclose(file);
    printf("Order saved successfully!\n");
}

void searchOrder(const char *name) {
    FILE *file = fopen("orders.txt", "r");
    if (file == NULL) {
        perror("Unable to open file");
        return;
    }

    char line[256];
    int found = 0;

    while (fgets(line, sizeof(line), file)) {
        if (strstr(line, name)) {
            found = 1;
            printf("\nOrder found:\n");
            do {
                printf("%s", line);
            } while (fgets(line, sizeof(line), file) && strcmp(line, "\n") != 0);
        }
    }

    if (!found) {
        printf("No order found for customer name: %s\n", name);
    }

    fclose(file);
}
