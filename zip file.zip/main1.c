#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "grocery_store.h"

int main() {
    // Login credentials
    const char* const USERNAME = "admin";
    const char* const PASSWORD = "password";

    char username[20];
    char password[20];

    printf("Welcome to our grocery store!\n");

    // Login
    printf("Please login to continue.\n");
    printf("Username: ");
    scanf("%19s", username); // Limit input to prevent buffer overflow
    printf("Password: ");
    scanf("%19s", password); // Limit input to prevent buffer overflow

    if (!login(username, password, USERNAME, PASSWORD)) {
        printf("Login failed. Exiting...\n");
        return 1;
    }

    struct GroceryItem groceryItems[5] = {{"Apple", 1.00}, {"Banana", 0.50}, {"Orange", 0.75}, {"Potato", 1.25}, {"Carrot", 0.89}};
    int choice;
    int quantity;
    float total = 0.0;
    char name[50];
    char email[100];
    char address[100];

    displayMenu(groceryItems, 5);

    printf("\nEnter your choice (1-5): ");
    scanf("%d", &choice);
    printf("Enter quantity: ");
    scanf("%d", &quantity);

    if (choice >= 1 && choice <= 5) {
        total += groceryItems[choice - 1].price * quantity;
        printf("Added %s to your cart.\n", groceryItems[choice - 1].name);
    } else {
        printf("Invalid choice. Please try again.\n");
        return 1;
    }

    getCustomerDetails(name, email, address);

    printf("\n\n--------- Order Summary ---------\n");
    printf("Customer Name: %s\n", name);
    printf("Customer Email: %s\n", email);
    printf("Customer Address: %s\n", address);
    printf("Total: $%.2f\n", total);

    saveOrder(name, email, address, &groceryItems[choice - 1], quantity);

    // Optionally, allow searching for an order
    char searchName[50];
    printf("\nEnter a customer name to search for their order: ");
    scanf("%49s", searchName);
    searchOrder(searchName);

    return 0;
}
